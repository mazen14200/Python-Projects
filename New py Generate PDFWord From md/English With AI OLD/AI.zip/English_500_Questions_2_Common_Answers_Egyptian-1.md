# أشهر 500 سؤال في الإنجليزية --- إجابتان شائعتان لكل سؤال

> **طريقة الاستخدام:** احفظ السؤال مع إجابتين طبيعيتين وشائعتين. الترجمة
> الموجودة هنا هي **للإجابة فقط** كما طلبت. الأسئلة مأخوذة من ملف
> الأسئلة السابق، مع الحفاظ على تقسيمه لتسهيل المذاكرة.

------------------------------------------------------------------------

## القسم العام: أشهر الأسئلة على الإطلاق

### How are you?

**Answer 1:** I'm good, thanks. = أنا كويس، شكرًا.

**Answer 2:** I'm doing pretty well, thanks. = أنا تمام إلى حد كبير،
شكرًا.

------------------------------------------------------------------------

### What's your name?

**Answer 1:** My name is Mazen. = اسمي مازن.

**Answer 2:** You can call me Mazen. = ممكن تناديني مازن.

------------------------------------------------------------------------

### Where are you from?

**Answer 1:** I'm from Egypt. = أنا من مصر.

**Answer 2:** I was born and raised in Egypt. = أنا اتولدت واتربيت في
مصر.

------------------------------------------------------------------------

### How old are you?

**Answer 1:** I'm in my twenties. = أنا في العشرينات.

**Answer 2:** I'm 26 years old. = عندي 26 سنة.

------------------------------------------------------------------------

### What do you do?

**Answer 1:** I'm a software developer. = أنا مطور برمجيات.

**Answer 2:** I work in the tech industry. = أنا بشتغل في مجال
التكنولوجيا.

------------------------------------------------------------------------

### Can you help me?

**Answer 1:** Sure, I'd be happy to help. = طبعًا، يسعدني أساعدك.

**Answer 2:** Of course. What do you need? = طبعًا. محتاج إيه؟

------------------------------------------------------------------------

### What time is it?

**Answer 1:** It's about three o'clock. = الساعة حوالي تلاتة.

**Answer 2:** It's almost half past three. = الساعة قربت تبقى تلاتة ونص.

------------------------------------------------------------------------

### Where is the bathroom?

**Answer 1:** It's down the hall on the left. = في آخر الطرقة على
الشمال.

**Answer 2:** It's right next to the elevator. = هو جنب الأسانسير على
طول.

------------------------------------------------------------------------

### How much is this?

**Answer 1:** It's about twenty dollars. = سعره حوالي عشرين دولار.

**Answer 2:** It's a little expensive, but the quality is good. = غالي
شوية، بس جودته كويسة.

------------------------------------------------------------------------

### Do you speak English?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's this?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you repeat that, please?

**Answer 1:** Sure, I'll say it again. = طبعًا، هقولها تاني.

**Answer 2:** Of course. Let me explain it more clearly. = طبعًا. خليني
أوضحها بشكل أكتر.

------------------------------------------------------------------------

### What does this mean?

**Answer 1:** Yes, I understand. = أيوه، أنا فاهم.

**Answer 2:** I understand the main idea, but I need a little more
explanation. = فاهم الفكرة الأساسية، بس محتاج شرح أكتر شوية.

------------------------------------------------------------------------

### Where do you live?

**Answer 1:** I live nearby. = أنا ساكن قريب.

**Answer 2:** I live in the city center. = أنا ساكن في وسط البلد.

------------------------------------------------------------------------

### Are you okay?

**Answer 1:** Yes, I'm okay. Thanks for asking. = أيوه، أنا كويس. شكرًا
إنك سألت.

**Answer 2:** I'm fine now. Don't worry. = أنا كويس دلوقتي. متقلقش.

------------------------------------------------------------------------

### What's wrong?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What are you doing?

**Answer 1:** I'm working on a new project. = أنا شغال على مشروع جديد.

**Answer 2:** I'm just taking a short break. = أنا باخد بريك صغير بس.

------------------------------------------------------------------------

### Why?

**Answer 1:** Because I think it's the best option. = عشان شايف إنه أحسن
اختيار.

**Answer 2:** Because we don't have enough time. = عشان معندناش وقت
كفاية.

------------------------------------------------------------------------

### How?

**Answer 1:** I'll show you step by step. = هوريك خطوة خطوة.

**Answer 2:** It's easier than it looks. = هي أسهل مما شكلها يبين.

------------------------------------------------------------------------

### When?

**Answer 1:** Probably tomorrow morning. = غالبًا بكرة الصبح.

**Answer 2:** I'll let you know as soon as I can. = هقولك أول ما أقدر.

------------------------------------------------------------------------

### Where?

**Answer 1:** It's over there, next to the entrance. = هو هناك، جنب
المدخل.

**Answer 2:** It's on the second floor. = هو في الدور التاني.

------------------------------------------------------------------------

### Who is this?

**Answer 1:** That's my friend, Ahmed. = ده صاحبي أحمد.

**Answer 2:** That's one of my colleagues. = ده واحد من زمايلي.

------------------------------------------------------------------------

### What happened?

**Answer 1:** I missed the bus, so I was late. = الأتوبيس فاتني، فعشان
كده اتأخرت.

**Answer 2:** There was a problem with the system. = كان فيه مشكلة في
السيستم.

------------------------------------------------------------------------

### Can I help you?

**Answer 1:** Yes, please. I'm looking for this address. = أيوه لو سمحت.
أنا بدور على العنوان ده.

**Answer 2:** No, thanks. I'm just looking around. = لأ شكرًا. أنا بتفرج
بس.

------------------------------------------------------------------------

### What's up?

**Answer 1:** I'm good, thanks. = أنا كويس، شكرًا.

**Answer 2:** I'm doing pretty well, thanks. = أنا تمام إلى حد كبير،
شكرًا.

------------------------------------------------------------------------

### Is everything okay?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you understand?

**Answer 1:** Yes, I understand. = أيوه، أنا فاهم.

**Answer 2:** I understand the main idea, but I need a little more
explanation. = فاهم الفكرة الأساسية، بس محتاج شرح أكتر شوية.

------------------------------------------------------------------------

### Can you speak slowly, please?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's your phone number?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### What's your email?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Are you married?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you have kids?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's your job?

**Answer 1:** I'm a software developer. = أنا مطور برمجيات.

**Answer 2:** I work in the tech industry. = أنا بشتغل في مجال
التكنولوجيا.

------------------------------------------------------------------------

### Where do you work?

**Answer 1:** I'm a software developer. = أنا مطور برمجيات.

**Answer 2:** I work in the tech industry. = أنا بشتغل في مجال
التكنولوجيا.

------------------------------------------------------------------------

### What's the weather like today?

**Answer 1:** It's warm and sunny today. = الجو دافي ومشمس النهارده.

**Answer 2:** It's a little hot, but it's nice. = الجو حر شوية، بس حلو.

------------------------------------------------------------------------

### Can I ask you a question?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you like it?

**Answer 1:** Yes, I really like it. = أيوه، أنا بحبه جدًا.

**Answer 2:** It's not really my thing. = مش أوي على ذوقي.

------------------------------------------------------------------------

### What do you think?

**Answer 1:** I think it's a good idea. = أنا شايف إنها فكرة كويسة.

**Answer 2:** In my opinion, we should consider another option. = في
رأيي، المفروض نفكر في اختيار تاني.

------------------------------------------------------------------------

### Are you sure?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can you hear me?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Is this seat taken?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I sit here?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's the matter?

**Answer 1:** I'm just a little tired. = أنا تعبان شوية بس.

**Answer 2:** Nothing serious. I'll be fine. = مفيش حاجة خطيرة. هبقى
كويس.

------------------------------------------------------------------------

### How was your day?

**Answer 1:** It was busy, but productive. = كان يوم زحمة، بس كان منتج.

**Answer 2:** It was pretty good. I got a lot done. = كان كويس جدًا.
أنجزت حاجات كتير.

------------------------------------------------------------------------

### Did you sleep well?

**Answer 1:** Yes, I slept really well. = أيوه، نمت كويس جدًا.

**Answer 2:** Not really. I woke up a few times. = مش أوي. صحيت كذا مرة.

------------------------------------------------------------------------

### Have you eaten?

**Answer 1:** Yes, I already ate. = أيوه، أنا أكلت خلاص.

**Answer 2:** Not yet. I'll eat later. = لسه. هاكل بعدين.

------------------------------------------------------------------------

### What are you going to do?

**Answer 1:** I'm planning to relax and spend time with my family. =
ناوي أرتاح وأقضي وقت مع عيلتي.

**Answer 2:** I haven't made any plans yet. = لسه معملتش أي خطط.

------------------------------------------------------------------------

### Where are you going?

**Answer 1:** I'm going home. = أنا رايح البيت.

**Answer 2:** I'm heading to work. = أنا رايح الشغل.

------------------------------------------------------------------------

### Can you give me a hand?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is that right?

**Answer 1:** Yes, that's right. = أيوه، صح.

**Answer 2:** I think so, but let me double-check. = أعتقد كده، بس خليني
أتأكد تاني.

------------------------------------------------------------------------

## المقابلات الشخصية والعمل

### Tell me about yourself.

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What are your strengths?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What are your weaknesses?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Why do you want this job?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Why should we hire you?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Where do you see yourself in five years?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What is your greatest achievement?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Why did you leave your last job?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What is your expected salary?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### When can you start?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Do you have any questions for us?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What do you know about our company?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### How do you handle stress?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Can you work under pressure?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What is your management style?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Are you a team player?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What motivates you?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Describe a challenge you faced at work.

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What are your career goals?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Are you willing to relocate?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What's your availability?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can you give me an update on the project?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What's the status of this task?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Is this report ready?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Can we schedule a meeting?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### What's the deadline for this?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Who is responsible for this?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Can you send me the file?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Have you finished the assignment?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What's your notice period?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Do you have any experience in this field?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### What skills do you bring to this role?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### How do you prioritize your tasks?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Can you walk me through your resume?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

### Do you have any references?

**Answer 1:** I have relevant experience and I'm eager to learn more. =
عندي خبرة مناسبة ومتحمس أتعلم أكتر.

**Answer 2:** I'm a strong team player, and I focus on solving problems
effectively. = أنا بعرف أشتغل كويس في فريق وبركز على حل المشاكل بكفاءة.

------------------------------------------------------------------------

## التعليم والتدريس

### What subject do you teach?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What grade are you in?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Have you done your homework?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Do you have any questions?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can you explain that again?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What did you learn today?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### When is the exam?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### How did you do on the test?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can you give me an example?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What's the difference between these two?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you help me understand this?

**Answer 1:** Yes, I understand. = أيوه، أنا فاهم.

**Answer 2:** I understand the main idea, but I need a little more
explanation. = فاهم الفكرة الأساسية، بس محتاج شرح أكتر شوية.

------------------------------------------------------------------------

### What are the learning objectives?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Is this going to be on the exam?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Can I ask a question, please?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What page are we on?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Did everyone understand the lesson?

**Answer 1:** Yes, I understand. = أيوه، أنا فاهم.

**Answer 2:** I understand the main idea, but I need a little more
explanation. = فاهم الفكرة الأساسية، بس محتاج شرح أكتر شوية.

------------------------------------------------------------------------

### What's the assignment for tomorrow?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Can you repeat the question?

**Answer 1:** Sure, I'll say it again. = طبعًا، هقولها تاني.

**Answer 2:** Of course. Let me explain it more clearly. = طبعًا. خليني
أوضحها بشكل أكتر.

------------------------------------------------------------------------

### How do you spell that?

**Answer 1:** Sure, I'll say it again. = طبعًا، هقولها تاني.

**Answer 2:** Of course. Let me explain it more clearly. = طبعًا. خليني
أوضحها بشكل أكتر.

------------------------------------------------------------------------

### What does this word mean?

**Answer 1:** Yes, I understand. = أيوه، أنا فاهم.

**Answer 2:** I understand the main idea, but I need a little more
explanation. = فاهم الفكرة الأساسية، بس محتاج شرح أكتر شوية.

------------------------------------------------------------------------

### Can we take a break?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Who wants to answer this question?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is my answer correct?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How can I improve my grades?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What's the syllabus for this course?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### When is the assignment due?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Can you recommend a good book?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### How long is the lecture?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What's the best way to study for this?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Do we have class tomorrow?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can I submit this late?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's my final grade?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Is attendance mandatory?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Can you give feedback on my work?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### How do students usually learn best?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

## البرمجة والتكنولوجيا

### What programming language should I learn first?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What's the difference between a bug and an error?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I fix this error?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What does this code do?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### Why is my code not working?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### Can you review my code?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's the best framework for this?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I optimize this function?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's the time complexity of this algorithm?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I deploy this project?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What database should I use?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How does this API work?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### Can you explain this concept?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What version of this library are you using?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I fix a merge conflict?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### Is this code secure?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I write clean code?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's the difference between frontend and backend?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I connect the frontend to the backend?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What is an API?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I write a unit test?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's the best way to learn coding?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### How do I improve my code's performance?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's the difference between SQL and NoSQL?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How does authentication work in this app?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### Can you debug this for me?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's a good project idea for beginners?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How do I host this website?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### What's the difference between Git and GitHub?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How do I scale this system?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### Is this the right architecture for the project?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's causing this bottleneck?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you refactor this function?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I secure this API?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's the best way to structure this project?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

## الويب والإنترنت

### Is the website down?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Why is the page loading so slowly?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### What browser are you using?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Is this website secure?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### How do I clear my browser cache?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### What's my IP address?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Why can't I connect to Wi-Fi?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Is my internet connection working?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### How do I reset my password?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's the URL for this?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### How do I improve my website's SEO?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Is this link safe to click?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### How do I create a website?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### What's a domain name?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### How much bandwidth do I need?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Why does this page keep crashing?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### How do I improve page speed?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Is my data encrypted?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's a good hosting provider?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### How do I embed a video on my site?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's responsive design?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Why isn't this form submitting?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How do I fix a 404 error?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### Is this site mobile-friendly?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### How do I back up my website?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

## الذكاء الاصطناعي

### Can AI replace human jobs?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How does machine learning work?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What's the difference between AI and machine learning?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Is AI dangerous?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How do I train a model?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What data does this model need?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can AI think like humans?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's a neural network?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How accurate is this model?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can AI write code?

**Answer 1:** I'd start by reproducing the problem and checking the
error message. = هبدأ إني أكرر المشكلة وأراجع رسالة الخطأ.

**Answer 2:** I'd debug it step by step and test the smallest part
first. = هدبجها خطوة خطوة وأختبر أصغر جزء الأول.

------------------------------------------------------------------------

### What's the best AI tool for this task?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How do I fine-tune a model?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Is this AI-generated content?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What are the ethical concerns of AI?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How does ChatGPT work?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's overfitting in machine learning?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### Can I use AI for free?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's a large language model?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How do I prevent AI bias?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Will AI take over the world?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's the future of AI?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How do I build a chatbot?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What skills do I need for AI?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Is this AI model open source?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How much data is needed to train an AI model?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's the difference between AI and automation?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How reliable are AI predictions?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can AI understand emotions?

**Answer 1:** Yes, I understand. = أيوه، أنا فاهم.

**Answer 2:** I understand the main idea, but I need a little more
explanation. = فاهم الفكرة الأساسية، بس محتاج شرح أكتر شوية.

------------------------------------------------------------------------

### What's prompt engineering?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How is AI used in education?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

## السفر والمطار

### Where is the check-in counter?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What time does the flight leave?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is the flight delayed?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Where is gate number five?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Can I see your passport, please?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### Do you have anything to declare?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where is my luggage?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is this seat available?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can I have a window seat?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's the baggage allowance?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How long is the layover?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Where can I exchange money?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is there a shuttle to the hotel?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where is the nearest taxi stand?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do I need a visa for this country?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's the purpose of your visit?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How long are you staying?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where are you staying?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is there Wi-Fi at the airport?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Can you call me a taxi?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's the fastest way to the city center?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is this the right terminal?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### How much is a ticket to the city center?

**Answer 1:** It's about twenty dollars. = سعره حوالي عشرين دولار.

**Answer 2:** It's a little expensive, but the quality is good. = غالي
شوية، بس جودته كويسة.

------------------------------------------------------------------------

### Can I get a refund on this ticket?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where's the lost and found?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is there a currency exchange nearby?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Can I bring this on the plane?

**Answer 1:** I'm planning to relax and spend time with my family. =
ناوي أرتاح وأقضي وقت مع عيلتي.

**Answer 2:** I haven't made any plans yet. = لسه معملتش أي خطط.

------------------------------------------------------------------------

### What's the weather like at my destination?

**Answer 1:** It's warm and sunny today. = الجو دافي ومشمس النهارده.

**Answer 2:** It's a little hot, but it's nice. = الجو حر شوية، بس حلو.

------------------------------------------------------------------------

### Do I need to change planes?

**Answer 1:** I'm planning to relax and spend time with my family. =
ناوي أرتاح وأقضي وقت مع عيلتي.

**Answer 2:** I haven't made any plans yet. = لسه معملتش أي خطط.

------------------------------------------------------------------------

### Is there a direct flight to Cairo?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

## الفنادق

### Do you have any rooms available?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What time is check-in?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What time is check-out?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Does the room have Wi-Fi?

**Answer 1:** I'd check the server, the network, and the browser console
first. = هراجع السيرفر والشبكة وكونسول المتصفح الأول.

**Answer 2:** I'd clear the cache and check the logs for errors. = هامسح
الكاش وأراجع اللوجز لو فيها أخطاء.

------------------------------------------------------------------------

### Is breakfast included?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can I get a wake-up call?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is there room service?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I change my room?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where is the elevator?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can I extend my stay?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Does the hotel have a pool?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What time does the gym close?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### Can you recommend a good restaurant nearby?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is parking available?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can I get a late check-out?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is there air conditioning in the room?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can you send someone to fix the AC?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### How far is the hotel from the airport?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Is there a minibar in the room?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I book a taxi from the front desk?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

## المطاعم والطعام

### Can I see the menu, please?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What do you recommend?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is this dish spicy?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you have any vegetarian options?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get the bill, please?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is service included?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you take credit cards?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Can I book a table for two?

**Answer 1:** I learn best by practicing and reviewing regularly. =
بتعلم أحسن لما أتمرن وأراجع باستمرار.

**Answer 2:** I usually learn by watching examples and trying things
myself. = عادةً بتعلم من الأمثلة وبجرب الحاجة بنفسي.

------------------------------------------------------------------------

### What's in this dish?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is this table free?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I have some water, please?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's today's special?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can I get this to go?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Does this contain nuts?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How long is the wait?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Can I change my order?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is the food halal?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can we split the bill?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you deliver?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What time do you close?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get a discount?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is this seat reserved?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get extra sauce?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What size does this come in?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you have a kids' menu?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

## التسوق

### How much does this cost?

**Answer 1:** It's about twenty dollars. = سعره حوالي عشرين دولار.

**Answer 2:** It's a little expensive, but the quality is good. = غالي
شوية، بس جودته كويسة.

------------------------------------------------------------------------

### Do you have this in a different size?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I try this on?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where is the fitting room?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you have this in another color?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is this on sale?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get a refund?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I exchange this?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you accept returns?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where can I pay?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you have a smaller size?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is there a warranty on this?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get a receipt?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you have any discounts today?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's your return policy?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you gift wrap this?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you have this item in stock?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I pay by card?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is this the final price?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where is the nearest mall?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

## الاتجاهات والمواصلات

### How do I get to the city center?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is it far from here?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you show me on the map?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Which bus goes to the airport?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Where's the nearest metro station?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How much is the fare?

**Answer 1:** It's about twenty dollars. = سعره حوالي عشرين دولار.

**Answer 2:** It's a little expensive, but the quality is good. = غالي
شوية، بس جودته كويسة.

------------------------------------------------------------------------

### Can you drop me off here?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is this the right way to the museum?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### How long does it take to get there?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do I need to change buses?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Where can I catch a taxi?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is there a train station nearby?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's the fastest route?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you turn on the meter, please?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Which platform does this train leave from?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Do you know how to get to this address?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is parking available here?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### How much is a one-way ticket?

**Answer 1:** It's about twenty dollars. = سعره حوالي عشرين دولار.

**Answer 2:** It's a little expensive, but the quality is good. = غالي
شوية، بس جودته كويسة.

------------------------------------------------------------------------

### Where should I get off?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can I walk there?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

## الهاتف والمكالمات

### Can I speak to Mr. Ahmed, please?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Who's calling, please?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Can you hold on a second?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can you call me back later?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Is this a good time to talk?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can you hear me okay?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Can I take a message?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### What's the best number to reach you?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Can you send me that in a text?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Sorry, can you repeat that?

**Answer 1:** Sure, I'll say it again. = طبعًا، هقولها تاني.

**Answer 2:** Of course. Let me explain it more clearly. = طبعًا. خليني
أوضحها بشكل أكتر.

------------------------------------------------------------------------

### Is the line busy?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you put me through to the manager?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's your extension number?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Did you get my message?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Can we do a video call instead?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

## الصحة والطبيب

### What's wrong with you?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Where does it hurt?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### How long have you had this pain?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Do you have any allergies?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Are you taking any medication?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you have a fever?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Can I make an appointment?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### What are the symptoms?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Is it serious?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How often should I take this medicine?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Do I need surgery?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Can you prescribe something for the pain?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Is this covered by insurance?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### When will the test results be ready?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you have any side effects from this?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get a second opinion?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### How's the recovery going?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do I need to fast before the test?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's my blood pressure?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Is this contagious?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can you refer me to a specialist?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### How long will I need to rest?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What should I eat and avoid?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is it safe to take this with other medicine?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Can you check my temperature?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

## الطوارئ

### Can you call an ambulance?

**Answer 1:** Yes, please call for help right away. = أيوه، لو سمحت اطلب
المساعدة فورًا.

**Answer 2:** I'm okay for now, but I need assistance. = أنا كويس حاليًا،
بس محتاج مساعدة.

------------------------------------------------------------------------

### I need help, please!

**Answer 1:** Sure, I'd be happy to help. = طبعًا، يسعدني أساعدك.

**Answer 2:** Of course. What do you need? = طبعًا. محتاج إيه؟

------------------------------------------------------------------------

### Where is the nearest hospital?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is anyone hurt?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Can you call the police?

**Answer 1:** Yes, please call for help right away. = أيوه، لو سمحت اطلب
المساعدة فورًا.

**Answer 2:** I'm okay for now, but I need assistance. = أنا كويس حاليًا،
بس محتاج مساعدة.

------------------------------------------------------------------------

### What's the emergency number here?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### There's a fire!

**Answer 1:** Yes, please call for help right away. = أيوه، لو سمحت اطلب
المساعدة فورًا.

**Answer 2:** I'm okay for now, but I need assistance. = أنا كويس حاليًا،
بس محتاج مساعدة.

------------------------------------------------------------------------

### I've lost my passport, what should I do?

**Answer 1:** Yes, please call for help right away. = أيوه، لو سمحت اطلب
المساعدة فورًا.

**Answer 2:** I'm okay for now, but I need assistance. = أنا كويس حاليًا،
بس محتاج مساعدة.

------------------------------------------------------------------------

### Can you help me find my child?

**Answer 1:** Sure, I'd be happy to help. = طبعًا، يسعدني أساعدك.

**Answer 2:** Of course. What do you need? = طبعًا. محتاج إيه؟

------------------------------------------------------------------------

### Is there a doctor nearby?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### I've been robbed, what should I do?

**Answer 1:** Yes, please call for help right away. = أيوه، لو سمحت اطلب
المساعدة فورًا.

**Answer 2:** I'm okay for now, but I need assistance. = أنا كويس حاليًا،
بس محتاج مساعدة.

------------------------------------------------------------------------

### Where's the nearest police station?

**Answer 1:** Yes, please call for help right away. = أيوه، لو سمحت اطلب
المساعدة فورًا.

**Answer 2:** I'm okay for now, but I need assistance. = أنا كويس حاليًا،
بس محتاج مساعدة.

------------------------------------------------------------------------

### Can you show me the emergency exit?

**Answer 1:** Yes, please call for help right away. = أيوه، لو سمحت اطلب
المساعدة فورًا.

**Answer 2:** I'm okay for now, but I need assistance. = أنا كويس حاليًا،
بس محتاج مساعدة.

------------------------------------------------------------------------

### Is it safe here?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### My car broke down, can you help?

**Answer 1:** Sure, I'd be happy to help. = طبعًا، يسعدني أساعدك.

**Answer 2:** Of course. What do you need? = طبعًا. محتاج إيه؟

------------------------------------------------------------------------

## العائلة والعلاقات

### Do you have any siblings?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### How many people are in your family?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### What does your father do?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Are your parents still alive?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### How long have you been married?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you get along with your family?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### How did you two meet?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Are you close to your family?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### What's your relationship status?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### Do you want to have children?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### How's your relationship with your parents?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### Who do you live with?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Are you the oldest child?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you visit your family often?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### What's your spouse's name?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### How do you handle disagreements?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Are you planning to start a family?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### Who's the head of your household?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you have a big family?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### How often do you talk to your parents?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

## المال والبنك

### How much money do I have in my account?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Can I open a bank account?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### What's the exchange rate today?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Can I withdraw money here?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Where's the nearest ATM?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Can I transfer money to another account?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### What's the interest rate on this loan?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### How do I apply for a credit card?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### What are the fees for this transaction?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Can I pay in installments?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Is my money safe in this bank?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### How do I check my balance?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Can you give me change for this?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's the minimum balance required?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### How long does a transfer take?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can I get a loan?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Do you accept this currency?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

### Where can I pay this bill?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is there a fee for using this card abroad?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get a copy of my statement?

**Answer 1:** I'd like to check my balance first. = عايز أشوف رصيدي
الأول.

**Answer 2:** I'd like to make a transfer. = عايز أعمل تحويل.

------------------------------------------------------------------------

## الطقس

### What's the weather like today?

**Answer 1:** It's warm and sunny today. = الجو دافي ومشمس النهارده.

**Answer 2:** It's a little hot, but it's nice. = الجو حر شوية، بس حلو.

------------------------------------------------------------------------

### Is it going to rain today?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's the temperature outside?

**Answer 1:** I've had this problem for a few days. = المشكلة دي بقالها
كام يوم.

**Answer 2:** It's not too bad, but it's bothering me. = مش شديدة أوي،
بس مضايقاني.

------------------------------------------------------------------------

### Is it hot or cold today?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do I need an umbrella?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's the forecast for tomorrow?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is it going to be sunny this weekend?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### How windy is it today?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Will it snow this winter?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is a storm coming?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

## الرياضة والهوايات

### What sports do you play?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### Do you follow football?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### Who's your favorite team?

**Answer 1:** Yes, I really like it. = أيوه، أنا بحبه جدًا.

**Answer 2:** It's not really my thing. = مش أوي على ذوقي.

------------------------------------------------------------------------

### What's the score?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you go to the gym?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### What do you do in your free time?

**Answer 1:** I'm a software developer. = أنا مطور برمجيات.

**Answer 2:** I work in the tech industry. = أنا بشتغل في مجال
التكنولوجيا.

------------------------------------------------------------------------

### Do you have any hobbies?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### How often do you exercise?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### Did you watch the match yesterday?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you play any musical instruments?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### What kind of music do you like?

**Answer 1:** Yes, I really like it. = أيوه، أنا بحبه جدًا.

**Answer 2:** It's not really my thing. = مش أوي على ذوقي.

------------------------------------------------------------------------

### Do you like reading books?

**Answer 1:** Yes, I really like it. = أيوه، أنا بحبه جدًا.

**Answer 2:** It's not really my thing. = مش أوي على ذوقي.

------------------------------------------------------------------------

### Have you ever tried swimming?

**Answer 1:** I play football and go to the gym. = بلعب كورة وبروح
الجيم.

**Answer 2:** I usually exercise a few times a week. = عادةً بتمرن كام
مرة في الأسبوع.

------------------------------------------------------------------------

### What's your favorite movie?

**Answer 1:** Yes, I really like it. = أيوه، أنا بحبه جدًا.

**Answer 2:** It's not really my thing. = مش أوي على ذوقي.

------------------------------------------------------------------------

### Do you enjoy traveling?

**Answer 1:** Yes, I really like it. = أيوه، أنا بحبه جدًا.

**Answer 2:** It's not really my thing. = مش أوي على ذوقي.

------------------------------------------------------------------------

## الاجتماعات وبيئة العمل

### Shall we start the meeting?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Can everyone hear me?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### What's on the agenda today?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Can you share your screen?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Does anyone have any questions?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can we move to the next point?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Who's taking the minutes?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Can we reschedule this meeting?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### What are the next steps?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Is everyone on the same page?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Can you summarize what we discussed?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Who's responsible for this task?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Can we set a deadline for this?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Is this meeting mandatory?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Can we take a five-minute break?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's the goal of this project?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Are we on track with the timeline?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can you loop me in on this?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Who else should be in this meeting?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

### Can we align on this before we proceed?

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

## الآراء والنقاش

### What's your opinion on this?

**Answer 1:** I think it's a good idea. = أنا شايف إنها فكرة كويسة.

**Answer 2:** In my opinion, we should consider another option. = في
رأيي، المفروض نفكر في اختيار تاني.

------------------------------------------------------------------------

### Do you agree with me?

**Answer 1:** I think it's a good idea. = أنا شايف إنها فكرة كويسة.

**Answer 2:** In my opinion, we should consider another option. = في
رأيي، المفروض نفكر في اختيار تاني.

------------------------------------------------------------------------

### Why do you think that?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What would you do in my situation?

**Answer 1:** I think it's a good idea. = أنا شايف إنها فكرة كويسة.

**Answer 2:** In my opinion, we should consider another option. = في
رأيي، المفروض نفكر في اختيار تاني.

------------------------------------------------------------------------

### Do you see my point?

**Answer 1:** I think it's a good idea. = أنا شايف إنها فكرة كويسة.

**Answer 2:** In my opinion, we should consider another option. = في
رأيي، المفروض نفكر في اختيار تاني.

------------------------------------------------------------------------

### Can you explain your reasoning?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### Is there another way to look at this?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's the pros and cons of this?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you have any evidence for that?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What would you change about this?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can we agree to disagree?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### What's the most important factor here?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Is this fair?

**Answer 1:** It depends on the model, the data, and the task. = ده
بيعتمد على الموديل والبيانات والمهمة.

**Answer 2:** I'd test it on real examples before relying on it. =
هختبره على أمثلة حقيقية قبل ما أعتمد عليه.

------------------------------------------------------------------------

### What's the solution to this problem?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you think this is a good idea?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

## سمول توك ومواقف اجتماعية عامة

### Long time no see, how have you been?

**Answer 1:** I'm good, thanks. = أنا كويس، شكرًا.

**Answer 2:** I'm doing pretty well, thanks. = أنا تمام إلى حد كبير،
شكرًا.

------------------------------------------------------------------------

### What have you been up to?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### How's the family?

**Answer 1:** We're pretty close. = إحنا قريبين من بعض جدًا.

**Answer 2:** We don't see each other every day, but we keep in touch. =
مش بنشوف بعض كل يوم، بس دايمًا على تواصل.

------------------------------------------------------------------------

### Did you have a good weekend?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Any plans for the holidays?

**Answer 1:** I'm planning to relax and spend time with my family. =
ناوي أرتاح وأقضي وقت مع عيلتي.

**Answer 2:** I haven't made any plans yet. = لسه معملتش أي خطط.

------------------------------------------------------------------------

### Have you been here before?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Do you come here often?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Is this your first time in Egypt?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What brings you here?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Can I get you something to drink?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Would you like to join us?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Did you enjoy the party?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What do you like to do for fun?

**Answer 1:** Yes, I really like it. = أيوه، أنا بحبه جدًا.

**Answer 2:** It's not really my thing. = مش أوي على ذوقي.

------------------------------------------------------------------------

### Are you free this weekend?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Shall we keep in touch?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### Can I get your number?

**Answer 1:** Sure, I'll call you back later. = طبعًا، هتصل بيك تاني
بعدين.

**Answer 2:** I'll send you a message instead. = هبعتلك رسالة بدل كده.

------------------------------------------------------------------------

### Would you like to grab a coffee sometime?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### What's new with you?

**Answer 1:** Yes, that's possible. = أيوه، ده ممكن.

**Answer 2:** It depends on the situation. = ده بيعتمد على الموقف.

------------------------------------------------------------------------

### Do you mind if I sit here?

**Answer 1:** Yes, definitely. = أيوه، أكيد.

**Answer 2:** Yes, I think so. = أيوه، أعتقد كده.

------------------------------------------------------------------------

### It was nice meeting you.

**Answer 1:** Yes, let's get started. = أيوه، يلا نبدأ.

**Answer 2:** I think we're ready to move on. = أعتقد إننا جاهزين نكمل.

------------------------------------------------------------------------

## ملاحظة للمذاكرة

-   لا تحفظ الإجابة حرفيًا فقط؛ احفظ **نمط السؤال + فكرة الإجابة**.
-   لو السؤال شخصي، غيّر الاسم أو المكان أو التفاصيل بما يناسبك.
-   الإجابات هنا أمثلة شائعة وطبيعية، وليست الإجابات الوحيدة الصحيحة.
